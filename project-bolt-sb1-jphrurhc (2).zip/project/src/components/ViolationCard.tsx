import React from 'react';
import { AlertTriangle, Clock, MapPin, Camera, Car } from 'lucide-react';

export interface Violation {
  id: string;
  type: 'red_light' | 'wrong_way' | 'lane_violation' | 'overspeeding';
  licensePlate: string;
  timestamp: string;
  location: string;
  confidence: number;
  vehicleType: string;
  frameUrl: string;
  severity: 'low' | 'medium' | 'high';
}

interface ViolationCardProps {
  violation: Violation;
  onClick: () => void;
}

const violationTypeLabels = {
  red_light: 'Red Light Violation',
  wrong_way: 'Wrong Way Driving',
  lane_violation: 'Lane Violation',
  overspeeding: 'Over Speeding'
};

const violationTypeColors = {
  red_light: 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400',
  wrong_way: 'bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400',
  lane_violation: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400',
  overspeeding: 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400'
};

const severityColors = {
  low: 'border-l-yellow-400',
  medium: 'border-l-orange-400',
  high: 'border-l-red-500'
};

export const ViolationCard: React.FC<ViolationCardProps> = ({ violation, onClick }) => {
  return (
    <div
      className={`bg-white dark:bg-gray-800 rounded-lg shadow-md border-l-4 ${severityColors[violation.severity]} p-6 cursor-pointer transition-all duration-200 hover:shadow-lg hover:scale-[1.02]`}
      onClick={onClick}
    >
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center space-x-2">
          <AlertTriangle className="w-5 h-5 text-red-500" />
          <span
            className={`px-2 py-1 rounded-full text-xs font-medium ${violationTypeColors[violation.type]}`}
          >
            {violationTypeLabels[violation.type]}
          </span>
        </div>
        <span className="text-xs text-gray-500 dark:text-gray-400 capitalize">
          {violation.severity} Priority
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <Camera className="w-4 h-4 text-gray-400" />
            <span className="text-sm text-gray-600 dark:text-gray-300">License Plate</span>
          </div>
          <div className="bg-gray-100 dark:bg-gray-700 rounded px-3 py-2">
            <span className="font-mono text-lg font-bold text-gray-900 dark:text-gray-100">
              {violation.licensePlate}
            </span>
          </div>

          <div className="space-y-2">
            <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-300">
              <Clock className="w-4 h-4" />
              <span>{violation.timestamp}</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-300">
              <MapPin className="w-4 h-4" />
              <span>{violation.location}</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-300">
              <Car className="w-4 h-4" />
              <span>{violation.vehicleType}</span>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <div className="aspect-video bg-gray-100 dark:bg-gray-700 rounded-lg overflow-hidden">
            <img
              src={violation.frameUrl}
              alt="Violation frame"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="text-center">
            <span className="text-xs text-gray-500 dark:text-gray-400">
              Confidence: {(violation.confidence * 100).toFixed(1)}%
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};