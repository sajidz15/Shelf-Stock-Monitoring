import React from 'react';
import { AlertTriangle, Clock, MapPin, Package, CheckCircle, User, TrendingDown } from 'lucide-react';
import { StockAlert } from '../types/shelf';

interface StockAlertCardProps {
  alert: StockAlert;
  onClick: () => void;
  onAcknowledge: () => void;
}

const alertTypeLabels = {
  low_stock: 'Low Stock',
  out_of_stock: 'Out of Stock',
  misplaced: 'Misplaced Product',
  overstocked: 'Overstocked'
};

const alertTypeColors = {
  low_stock: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400',
  out_of_stock: 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400',
  misplaced: 'bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400',
  overstocked: 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400'
};

const severityColors = {
  low: 'border-l-yellow-400',
  medium: 'border-l-orange-400',
  high: 'border-l-red-500',
  critical: 'border-l-red-600'
};

const alertIcons = {
  low_stock: TrendingDown,
  out_of_stock: Package,
  misplaced: MapPin,
  overstocked: Package
};

export const StockAlertCard: React.FC<StockAlertCardProps> = ({ alert, onClick, onAcknowledge }) => {
  const AlertIcon = alertIcons[alert.alertType];
  
  return (
    <div
      className={`bg-white dark:bg-gray-800 rounded-lg shadow-md border-l-4 ${severityColors[alert.severity]} p-6 transition-all duration-200 hover:shadow-lg ${
        alert.acknowledged ? 'opacity-75' : ''
      }`}
    >
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center space-x-2">
          <AlertIcon className="w-5 h-5 text-red-500" />
          <span
            className={`px-2 py-1 rounded-full text-xs font-medium ${alertTypeColors[alert.alertType]}`}
          >
            {alertTypeLabels[alert.alertType]}
          </span>
          {alert.acknowledged && (
            <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400">
              Acknowledged
            </span>
          )}
        </div>
        <span className="text-xs text-gray-500 dark:text-gray-400 capitalize">
          {alert.severity} Priority
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <Package className="w-4 h-4 text-gray-400" />
            <span className="text-sm text-gray-600 dark:text-gray-300">Product</span>
          </div>
          <div className="bg-gray-100 dark:bg-gray-700 rounded px-3 py-2">
            <span className="font-semibold text-lg text-gray-900 dark:text-gray-100">
              {alert.productName}
            </span>
          </div>

          <div className="space-y-2">
            <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-300">
              <Clock className="w-4 h-4" />
              <span>{alert.timestamp}</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-300">
              <MapPin className="w-4 h-4" />
              <span>{alert.shelfSection}</span>
            </div>
            {alert.assignedTo && (
              <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-300">
                <User className="w-4 h-4" />
                <span>Assigned to: {alert.assignedTo}</span>
              </div>
            )}
          </div>

          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-3">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Stock Level</span>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-center">
                <div className="text-lg font-bold text-red-600">{alert.currentStock}</div>
                <div className="text-xs text-gray-500">Current</div>
              </div>
              <div className="text-gray-400">/</div>
              <div className="text-center">
                <div className="text-lg font-bold text-gray-900 dark:text-gray-100">{alert.expectedStock}</div>
                <div className="text-xs text-gray-500">Expected</div>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <div className="aspect-video bg-gray-100 dark:bg-gray-700 rounded-lg overflow-hidden">
            <img
              src={alert.imageUrl}
              alt="Shelf section"
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="flex space-x-2">
            <button
              onClick={onClick}
              className="flex-1 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 text-sm"
            >
              View Details
            </button>
            {!alert.acknowledged && (
              <button
                onClick={onAcknowledge}
                className="flex items-center space-x-1 px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200 text-sm"
              >
                <CheckCircle className="w-4 h-4" />
                <span>Acknowledge</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};