import React, { useState, useEffect } from 'react';
import { Scan, Package, AlertTriangle, CheckCircle, Camera, BarChart3 } from 'lucide-react';

interface AnalysisStep {
  id: string;
  label: string;
  icon: React.ReactNode;
  duration: number;
  status: 'pending' | 'active' | 'completed';
}

interface StockAnalysisProgressProps {
  isAnalyzing: boolean;
  onAnalysisComplete: () => void;
}

export const StockAnalysisProgress: React.FC<StockAnalysisProgressProps> = ({ 
  isAnalyzing, 
  onAnalysisComplete 
}) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [progress, setProgress] = useState(0);

  const steps: AnalysisStep[] = [
    {
      id: 'preprocessing',
      label: 'Preprocessing shelf image',
      icon: <Camera className="w-5 h-5" />,
      duration: 1500,
      status: 'pending'
    },
    {
      id: 'segmentation',
      label: 'Segmenting shelf regions',
      icon: <Scan className="w-5 h-5" />,
      duration: 2000,
      status: 'pending'
    },
    {
      id: 'detection',
      label: 'Detecting products and empty spaces',
      icon: <Package className="w-5 h-5" />,
      duration: 2500,
      status: 'pending'
    },
    {
      id: 'counting',
      label: 'Counting stock levels',
      icon: <BarChart3 className="w-5 h-5" />,
      duration: 1800,
      status: 'pending'
    },
    {
      id: 'alerts',
      label: 'Generating stock alerts',
      icon: <AlertTriangle className="w-5 h-5" />,
      duration: 1200,
      status: 'pending'
    }
  ];

  useEffect(() => {
    if (!isAnalyzing) {
      setCurrentStep(0);
      setProgress(0);
      return;
    }

    let stepIndex = 0;
    let progressValue = 0;

    const runStep = () => {
      if (stepIndex >= steps.length) {
        onAnalysisComplete();
        return;
      }

      const step = steps[stepIndex];
      const stepProgress = 100 / steps.length;
      const startProgress = stepIndex * stepProgress;

      const interval = setInterval(() => {
        progressValue += 2;
        const currentStepProgress = Math.min(progressValue, stepProgress);
        setProgress(startProgress + currentStepProgress);
        setCurrentStep(stepIndex);

        if (progressValue >= stepProgress) {
          clearInterval(interval);
          progressValue = 0;
          stepIndex++;
          setTimeout(runStep, 200);
        }
      }, step.duration / 50);
    };

    runStep();
  }, [isAnalyzing, onAnalysisComplete]);

  if (!isAnalyzing) return null;

  return (
    <div className="w-full max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
      <div className="space-y-6">
        <div className="text-center">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">
            Analyzing Shelf Stock Levels
          </h3>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            AI-powered computer vision analysis in progress...
          </p>
        </div>

        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs text-gray-600 dark:text-gray-400">
            <span>Analysis Progress</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
            <div
              className="bg-gradient-to-r from-blue-500 to-green-500 h-2 rounded-full transition-all duration-200 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Analysis Steps */}
        <div className="space-y-3">
          {steps.map((step, index) => {
            const isActive = index === currentStep;
            const isCompleted = index < currentStep;
            const isPending = index > currentStep;

            return (
              <div
                key={step.id}
                className={`flex items-center space-x-3 p-3 rounded-lg transition-all duration-300 ${
                  isActive
                    ? 'bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800'
                    : isCompleted
                    ? 'bg-green-50 dark:bg-green-900/20'
                    : 'bg-gray-50 dark:bg-gray-700/50'
                }`}
              >
                <div
                  className={`p-2 rounded-full transition-colors duration-300 ${
                    isActive
                      ? 'bg-blue-100 dark:bg-blue-800 text-blue-600 dark:text-blue-400'
                      : isCompleted
                      ? 'bg-green-100 dark:bg-green-800 text-green-600 dark:text-green-400'
                      : 'bg-gray-100 dark:bg-gray-600 text-gray-400'
                  }`}
                >
                  {isCompleted ? <CheckCircle className="w-5 h-5" /> : step.icon}
                </div>
                <span
                  className={`text-sm font-medium transition-colors duration-300 ${
                    isActive
                      ? 'text-blue-700 dark:text-blue-300'
                      : isCompleted
                      ? 'text-green-700 dark:text-green-300'
                      : 'text-gray-500 dark:text-gray-400'
                  }`}
                >
                  {step.label}
                </span>
                {isActive && (
                  <div className="ml-auto">
                    <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};