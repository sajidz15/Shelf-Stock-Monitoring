import React, { useState } from 'react';
import { ShoppingCart, Moon, Sun, Upload, BarChart3, Scan, Bell } from 'lucide-react';

interface HeaderProps {
  appState: 'upload' | 'analyzing' | 'results';
  onNewAnalysis: () => void;
  uploadedFile: File | null;
  alertsCount: number;
}

export const Header: React.FC<HeaderProps> = ({ 
  appState, 
  onNewAnalysis, 
  uploadedFile,
  alertsCount 
}) => {
  const [isDarkMode, setIsDarkMode] = useState(false);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
  };

  const getStatusText = () => {
    switch (appState) {
      case 'upload':
        return 'Ready to scan shelves';
      case 'analyzing':
        return `Analyzing ${uploadedFile?.name || 'shelf image'}...`;
      case 'results':
        return `Analysis complete - ${alertsCount} alerts generated`;
      default:
        return '';
    }
  };

  const getStatusIcon = () => {
    switch (appState) {
      case 'upload':
        return <Upload className="w-4 h-4" />;
      case 'analyzing':
        return <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />;
      case 'results':
        return <BarChart3 className="w-4 h-4" />;
      default:
        return null;
    }
  };

  return (
    <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo and Title */}
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-r from-green-500 to-blue-600 rounded-lg">
              <ShoppingCart className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100">
                ShelfWatch AI
              </h1>
              <div className="flex items-center space-x-2 text-xs text-gray-500 dark:text-gray-400">
                {getStatusIcon()}
                <span>{getStatusText()}</span>
              </div>
            </div>
          </div>

          {/* Navigation and Controls */}
          <div className="flex items-center space-x-4">
            {/* Alerts Badge */}
            {appState === 'results' && alertsCount > 0 && (
              <div className="relative">
                <Bell className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {alertsCount > 99 ? '99+' : alertsCount}
                </span>
              </div>
            )}

            {appState === 'results' && (
              <button
                onClick={onNewAnalysis}
                className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
              >
                <Scan className="w-4 h-4" />
                <span className="hidden sm:inline">New Scan</span>
              </button>
            )}

            <button
              onClick={toggleDarkMode}
              className="p-2 rounded-lg bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200"
              aria-label="Toggle dark mode"
            >
              {isDarkMode ? (
                <Sun className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              ) : (
                <Moon className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              )}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};