export interface Product {
  id: string;
  name: string;
  category: string;
  expectedCount: number;
  currentCount: number;
  position: {
    shelf: number;
    row: number;
    column: number;
  };
  lastRestocked: string;
  threshold: number;
  price: number;
  sku: string;
}

export interface ShelfSection {
  id: string;
  name: string;
  camera: string;
  products: Product[];
  lastScanned: string;
  status: 'normal' | 'low_stock' | 'out_of_stock' | 'overstocked';
}

export interface StockAlert {
  id: string;
  productId: string;
  productName: string;
  alertType: 'low_stock' | 'out_of_stock' | 'misplaced' | 'overstocked';
  severity: 'low' | 'medium' | 'high' | 'critical';
  shelfSection: string;
  currentStock: number;
  expectedStock: number;
  timestamp: string;
  imageUrl: string;
  acknowledged: boolean;
  assignedTo?: string;
}

export interface AnalysisResult {
  shelfId: string;
  totalProducts: number;
  lowStockItems: number;
  outOfStockItems: number;
  confidence: number;
  processingTime: number;
  alerts: StockAlert[];
}