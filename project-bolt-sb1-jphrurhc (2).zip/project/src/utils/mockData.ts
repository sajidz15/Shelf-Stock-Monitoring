import { Violation } from '../components/ViolationCard';

// Mock data generator for demonstration purposes
export const generateMockViolations = (): Violation[] => {
  const violationTypes: Violation['type'][] = ['red_light', 'wrong_way', 'lane_violation', 'overspeeding'];
  const severities: Violation['severity'][] = ['low', 'medium', 'high'];
  const vehicleTypes = ['Sedan', 'SUV', 'Hatchback', 'Truck', 'Motorcycle', 'Van'];
  const locations = [
    'Main St & 5th Ave Intersection',
    'Highway 101 Exit Ramp',
    'Downtown Traffic Circle',
    'School Zone - Oak Street',
    'Business District Crossing',
    'Airport Road Junction'
  ];

  const mockPlates = [
    'ABC123', 'XYZ789', 'DEF456', 'GHI012', 'JKL345', 'MNO678',
    'PQR901', 'STU234', 'VWX567', 'YZA890', 'BCD123', 'EFG456'
  ];

  // Generate sample image URLs from Pexels
  const sampleImages = [
    'https://images.pexels.com/photos/210019/pexels-photo-210019.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/544966/pexels-photo-544966.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/1119796/pexels-photo-1119796.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/1637859/pexels-photo-1637859.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/2889690/pexels-photo-2889690.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/1545743/pexels-photo-1545743.jpeg?auto=compress&cs=tinysrgb&w=400'
  ];

  const violations: Violation[] = [];
  const violationCount = Math.floor(Math.random() * 8) + 3; // 3-10 violations

  for (let i = 0; i < violationCount; i++) {
    const baseTime = new Date();
    baseTime.setMinutes(baseTime.getMinutes() - Math.floor(Math.random() * 1440)); // Last 24 hours

    violations.push({
      id: `violation-${i + 1}`,
      type: violationTypes[Math.floor(Math.random() * violationTypes.length)],
      licensePlate: mockPlates[Math.floor(Math.random() * mockPlates.length)],
      timestamp: baseTime.toLocaleString(),
      location: locations[Math.floor(Math.random() * locations.length)],
      confidence: 0.75 + Math.random() * 0.24, // 75-99% confidence
      vehicleType: vehicleTypes[Math.floor(Math.random() * vehicleTypes.length)],
      frameUrl: sampleImages[Math.floor(Math.random() * sampleImages.length)],
      severity: severities[Math.floor(Math.random() * severities.length)]
    });
  }

  return violations;
};

export const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

export const formatDuration = (seconds: number): string => {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  
  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  } else {
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  }
};