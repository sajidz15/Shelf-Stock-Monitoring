import { StockAlert, Product, ShelfSection } from '../types/shelf';

// Mock data generator for retail shelf monitoring
export const generateMockStockAlerts = (): StockAlert[] => {
  const alertTypes: StockAlert['alertType'][] = ['low_stock', 'out_of_stock', 'misplaced', 'overstocked'];
  const severities: StockAlert['severity'][] = ['low', 'medium', 'high', 'critical'];
  
  const products = [
    'Coca-Cola 12oz Cans', 'Pepsi 2L Bottles', 'Lay\'s Potato Chips', 'Oreo Cookies',
    'Tide Laundry Detergent', 'Charmin Toilet Paper', 'Wonder Bread', 'Milk 1 Gallon',
    'Bananas', 'Apples Red Delicious', 'Ground Beef 1lb', 'Chicken Breast',
    'Cheerios Cereal', 'Kraft Mac & Cheese', 'Campbell\'s Soup', 'Pringles Original'
  ];

  const shelfSections = [
    'Aisle 1 - Beverages', 'Aisle 2 - Snacks', 'Aisle 3 - Dairy', 'Aisle 4 - Produce',
    'Aisle 5 - Meat', 'Aisle 6 - Cereal', 'Aisle 7 - Canned Goods', 'End Cap A',
    'End Cap B', 'Checkout Lane 1', 'Checkout Lane 2', 'Customer Service'
  ];

  const staffMembers = ['John Smith', 'Sarah Johnson', 'Mike Davis', 'Lisa Chen', 'David Wilson'];

  // Sample shelf images from Pexels
  const shelfImages = [
    'https://images.pexels.com/photos/264636/pexels-photo-264636.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/1005638/pexels-photo-1005638.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/2292919/pexels-photo-2292919.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/4199098/pexels-photo-4199098.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/4199100/pexels-photo-4199100.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/4199102/pexels-photo-4199102.jpeg?auto=compress&cs=tinysrgb&w=400'
  ];

  const alerts: StockAlert[] = [];
  const alertCount = Math.floor(Math.random() * 12) + 5; // 5-16 alerts

  for (let i = 0; i < alertCount; i++) {
    const alertType = alertTypes[Math.floor(Math.random() * alertTypes.length)];
    const productName = products[Math.floor(Math.random() * products.length)];
    const baseTime = new Date();
    baseTime.setMinutes(baseTime.getMinutes() - Math.floor(Math.random() * 2880)); // Last 48 hours

    // Generate realistic stock numbers based on alert type
    let currentStock = 0;
    let expectedStock = Math.floor(Math.random() * 50) + 10;
    
    switch (alertType) {
      case 'out_of_stock':
        currentStock = 0;
        break;
      case 'low_stock':
        currentStock = Math.floor(expectedStock * 0.2); // 20% or less
        break;
      case 'overstocked':
        currentStock = Math.floor(expectedStock * 1.5); // 150% or more
        expectedStock = currentStock;
        break;
      case 'misplaced':
        currentStock = Math.floor(expectedStock * 0.7);
        break;
    }

    alerts.push({
      id: `alert-${i + 1}`,
      productId: `product-${Math.floor(Math.random() * 1000)}`,
      productName,
      alertType,
      severity: severities[Math.floor(Math.random() * severities.length)],
      shelfSection: shelfSections[Math.floor(Math.random() * shelfSections.length)],
      currentStock,
      expectedStock,
      timestamp: baseTime.toLocaleString(),
      imageUrl: shelfImages[Math.floor(Math.random() * shelfImages.length)],
      acknowledged: Math.random() > 0.7, // 30% chance of being acknowledged
      assignedTo: Math.random() > 0.5 ? staffMembers[Math.floor(Math.random() * staffMembers.length)] : undefined
    });
  }

  return alerts;
};

export const generateMockProducts = (): Product[] => {
  const categories = ['Beverages', 'Snacks', 'Dairy', 'Produce', 'Meat', 'Cereal', 'Canned Goods'];
  const products: Product[] = [];

  for (let i = 0; i < 50; i++) {
    const category = categories[Math.floor(Math.random() * categories.length)];
    const expectedCount = Math.floor(Math.random() * 50) + 10;
    const currentCount = Math.floor(Math.random() * expectedCount);
    
    products.push({
      id: `product-${i + 1}`,
      name: `Product ${i + 1}`,
      category,
      expectedCount,
      currentCount,
      position: {
        shelf: Math.floor(Math.random() * 10) + 1,
        row: Math.floor(Math.random() * 5) + 1,
        column: Math.floor(Math.random() * 8) + 1
      },
      lastRestocked: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString(),
      threshold: Math.floor(expectedCount * 0.2), // 20% threshold
      price: Math.random() * 20 + 1,
      sku: `SKU${String(i + 1).padStart(6, '0')}`
    });
  }

  return products;
};

export const generateMockShelfSections = (): ShelfSection[] => {
  const sections: ShelfSection[] = [];
  const sectionNames = [
    'Beverages Section', 'Snacks Aisle', 'Dairy Cooler', 'Fresh Produce',
    'Meat Department', 'Cereal Aisle', 'Canned Goods', 'Checkout Area'
  ];

  for (let i = 0; i < sectionNames.length; i++) {
    const products = generateMockProducts().slice(0, Math.floor(Math.random() * 8) + 3);
    const statuses: ShelfSection['status'][] = ['normal', 'low_stock', 'out_of_stock', 'overstocked'];
    
    sections.push({
      id: `section-${i + 1}`,
      name: sectionNames[i],
      camera: `Camera-${String.fromCharCode(65 + i)}`, // Camera-A, Camera-B, etc.
      products,
      lastScanned: new Date(Date.now() - Math.random() * 60 * 60 * 1000).toISOString(),
      status: statuses[Math.floor(Math.random() * statuses.length)]
    });
  }

  return sections;
};

export const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

export const getStockPercentage = (current: number, expected: number): number => {
  if (expected === 0) return 0;
  return Math.round((current / expected) * 100);
};

export const getStockStatus = (current: number, expected: number, threshold: number): 'normal' | 'low' | 'out' | 'over' => {
  if (current === 0) return 'out';
  if (current <= threshold) return 'low';
  if (current > expected * 1.2) return 'over';
  return 'normal';
};