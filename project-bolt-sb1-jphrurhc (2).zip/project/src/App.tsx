import React, { useState } from 'react';
import { ShelfImageUpload } from './components/ShelfImageUpload';
import { StockAnalysisProgress } from './components/StockAnalysisProgress';
import { StockDashboard } from './components/StockDashboard';
import { StockAlert } from './types/shelf';
import { Header } from './components/Header';
import { generateMockStockAlerts } from './utils/mockShelfData';
import { ShoppingCart, Shield, Brain, Zap, Package, TrendingUp, BarChart3, Camera } from 'lucide-react';

type AppState = 'upload' | 'analyzing' | 'results';

function App() {
  const [appState, setAppState] = useState<AppState>('upload');
  const [alerts, setAlerts] = useState<StockAlert[]>([]);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);

  const handleImageUpload = (file: File) => {
    setUploadedFile(file);
    setAppState('analyzing');
  };

  const handleAnalysisComplete = () => {
    // Simulate AI analysis results
    const mockAlerts = generateMockStockAlerts();
    setAlerts(mockAlerts);
    setAppState('results');
  };

  const handleNewAnalysis = () => {
    setAppState('upload');
    setAlerts([]);
    setUploadedFile(null);
  };

  const renderContent = () => {
    switch (appState) {
      case 'upload':
        return (
          <div className="space-y-12">
            {/* Hero Section */}
            <div className="text-center space-y-6">
              <div className="flex justify-center">
                <div className="p-4 bg-gradient-to-r from-green-500 to-blue-600 rounded-full">
                  <ShoppingCart className="w-12 h-12 text-white" />
                </div>
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-gray-100">
                ShelfWatch AI
              </h1>
              <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto leading-relaxed">
                Automated retail shelf stock monitoring using advanced computer vision. 
                Detect empty shelves, low stock levels, and misplaced products in real-time 
                to optimize inventory management and improve customer satisfaction.
              </p>
            </div>

            {/* Features Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="p-2 bg-red-100 dark:bg-red-900/30 rounded-lg">
                    <Package className="w-6 h-6 text-red-600 dark:text-red-400" />
                  </div>
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100">Stock Detection</h3>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Automatically detects empty shelves, low stock levels, and out-of-stock situations
                </p>
              </div>

              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
                    <Brain className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100">AI Recognition</h3>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Advanced neural networks for accurate product identification and shelf segmentation
                </p>
              </div>

              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-lg">
                    <TrendingUp className="w-6 h-6 text-green-600 dark:text-green-400" />
                  </div>
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100">Real-time Alerts</h3>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Instant notifications to staff when restocking is needed or products are misplaced
                </p>
              </div>

              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="p-2 bg-purple-100 dark:bg-purple-900/30 rounded-lg">
                    <BarChart3 className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                  </div>
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100">Analytics Dashboard</h3>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Comprehensive reporting and analytics for inventory optimization and trend analysis
                </p>
              </div>
            </div>

            {/* Technology Stack */}
            <div className="bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-700 rounded-xl p-8">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-6 text-center">
                Powered by Advanced Computer Vision
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="bg-white dark:bg-gray-600 rounded-lg p-4 mb-3">
                    <Camera className="w-8 h-8 text-blue-600 mx-auto" />
                  </div>
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100">OpenCV</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Image Processing</p>
                </div>
                <div className="text-center">
                  <div className="bg-white dark:bg-gray-600 rounded-lg p-4 mb-3">
                    <Brain className="w-8 h-8 text-green-600 mx-auto" />
                  </div>
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100">YOLOv8</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Object Detection</p>
                </div>
                <div className="text-center">
                  <div className="bg-white dark:bg-gray-600 rounded-lg p-4 mb-3">
                    <Shield className="w-8 h-8 text-purple-600 mx-auto" />
                  </div>
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100">Edge Computing</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Raspberry Pi / Jetson</p>
                </div>
                <div className="text-center">
                  <div className="bg-white dark:bg-gray-600 rounded-lg p-4 mb-3">
                    <Zap className="w-8 h-8 text-orange-600 mx-auto" />
                  </div>
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100">MQTT/HTTP</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Real-time Alerts</p>
                </div>
              </div>
            </div>

            {/* Upload Section */}
            <ShelfImageUpload onImageUpload={handleImageUpload} isAnalyzing={false} />

            {/* Industry Benefits */}
            <div className="bg-white dark:bg-gray-800 rounded-xl p-8 shadow-lg">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-6 text-center">
                Industry Impact & Benefits
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
                    🎯 Business Benefits
                  </h3>
                  <ul className="space-y-2 text-gray-600 dark:text-gray-400">
                    <li>• Reduce out-of-stock events by up to 40%</li>
                    <li>• Improve customer satisfaction and sales</li>
                    <li>• Optimize staff productivity and efficiency</li>
                    <li>• Lower operational costs through automation</li>
                    <li>• Real-time inventory visibility</li>
                  </ul>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
                    🚀 Career Opportunities
                  </h3>
                  <ul className="space-y-2 text-gray-600 dark:text-gray-400">
                    <li>• Computer Vision Engineer</li>
                    <li>• AI for Retail Specialist</li>
                    <li>• Embedded Vision Developer</li>
                    <li>• IoT Smart Retail Solutions</li>
                    <li>• Retail Technology Consultant</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        );
      case 'analyzing':
        return (
          <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-8">
            <StockAnalysisProgress isAnalyzing={true} onAnalysisComplete={handleAnalysisComplete} />
          </div>
        );
      case 'results':
        return <StockDashboard alerts={alerts} />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      <Header 
        appState={appState} 
        onNewAnalysis={handleNewAnalysis}
        uploadedFile={uploadedFile}
        alertsCount={alerts.length}
      />
      
      <main className="container mx-auto px-4 py-8">
        {renderContent()}
      </main>
    </div>
  );
}

export default App;